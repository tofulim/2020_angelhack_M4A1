package com.example.garam.angelhack

class urlData (
    val tid : String,
    val url : String
)