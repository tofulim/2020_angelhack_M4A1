package com.example.garam.angelhack.Manager

class userList(
    val userName : String,
    val remain_money : String
)