package com.example.garam.angelhack.Manager

class payList(
     val before_money: String,
     val usemoney : String,
     val usingTime : String
)